﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SelectableCollider : MonoBehaviour
{
    public SelectableObject SelectableObject;
}
